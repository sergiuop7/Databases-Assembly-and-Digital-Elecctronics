<?php
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$place = $_POST['place'];
$address = $_POST['address'];
$birthday = $_POST['birthday'];
$gender = $_POST['gender'];
$year = $_POST['year'];
$scholarship = $_POST['scholarship'];


echo "Name : " .$fname."<br>";
echo "Surname : " .$lname."<br>";
echo "Gender : " .$gender."<br>";
echo "Date of birth : " .$birthday."<br>";
echo "Year of study : " .$year."<br>"; 
    if($scholarship == "Yes") {
       echo "Takes scholarship";
    } else {
        echo "Doesn't take scholarship";
    }

Age: <?php echo date("Y") - date("Y", strtotime($birthday)); ?><br>

echo " The student name is ".$fname." ".$lname."<br>";

$array = array("Data Bases", "Mathematics", "Software Engineering", "Physics");

echo "The main subjects are: <br>";
echo "<ul>";
for ($i = 0; $i < 4; $i++) {
    echo "<li>".$array[$i]."</li>";
}
  echo "</ul>";
  
echo "<br>The main rules are: <br>";
echo "<ol>";
echo "<li>Respect and listen to the teacher and students.</li>";
echo "<li>Raise your hand to speak.</li>";
echo "<li>Be prepared for class.</li>";
echo "</ol>";
?><br>